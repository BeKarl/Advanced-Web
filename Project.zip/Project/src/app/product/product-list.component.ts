import { Component } from '@angular/core';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  // styleUrls: ['../app.component.css']
})
export class ProductListComponent {
  counter = 0;
  num = 0;

  number = 9542.14554;
  //
  // a: number = 0.259;
  // b: number = 1.3495;
  //

  celcius: number;
  fahrenheit: number;


  toDate: Date = new Date();

  arr = [1, 2, 3, 4, 5, 6, 7, 8];

  input = 'Hello, welcome to Angular Course';

  products = [
    {id: 1, name: 'banana', price: 100},
    {id: 2, name: 'apple', price: 200},
    {id: 3, name: 'pineapple', price: 500}
  ];

  getColor(price: number) {
    if (price<=100) {
      return 'green';
    } else if (price <= 200) {
      return 'blue';
    } else {
      return 'red';
    }
  }

  btnClicked() {
    this.counter = this.counter + 1;
  }

  inputClicked(event) {
    this.input = event.target.value;
    console.log('input clicked!', event.target.value);
  }
}

