import {AfterViewInit, Component, ElementRef} from '@angular/core';
import {LoggingService} from './service/logging.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements AfterViewInit {
  title = 'Project';
  toDate = Date.now();
  constructor(private loggingService: LoggingService, private elementRef: ElementRef) {
    this.loggingService.log('Logging service work correctly');
  }
  ngAfterViewInit(){
    this.elementRef.nativeElement.ownerDocument.body.style.backgroundColor = '#F0FFFF';
  }
}

