import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';


import { AppComponent } from './app.component';
import { LinksComponent } from './links/links.component';
import {AppRoutingModule} from './app-routing.module';
import { ProductListComponent } from './product/product-list.component';
import {ReactiveFormsModule} from '@angular/forms';
import {FormsModule} from '@angular/forms';
import { TransforPipe } from './pipe/transfor.pipe';
import {SharedModule} from './shared/shared.module';
import {AuthModule} from './auth/auth.module';
import {UserService} from './service/user.service';
import {UserGuardService} from './guards/user-guard.service';
import {AeroCanDeactService} from './guards/aero-can-deact.service';
import {ContResolverService} from './guards/cont-resolver.service';
import {ContentModule} from './content/content.module';
import {HttpClient} from '@angular/common/http';

import { NgImageSliderModule } from 'ng-image-slider';
@NgModule({
  declarations: [
    AppComponent,
    LinksComponent,
    ProductListComponent,
    TransforPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    SharedModule,
    AuthModule,
    ReactiveFormsModule,
    ContentModule,
    NgImageSliderModule
  ],
  providers: [UserService,
              UserGuardService,
              AeroCanDeactService,
              HttpClient,
              ContResolverService],
  bootstrap: [AppComponent]
})
export class AppModule {
}
