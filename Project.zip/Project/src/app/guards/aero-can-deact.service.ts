import {ActivatedRouteSnapshot, CanDeactivate, Router, RouterStateSnapshot} from '@angular/router';
import {Injectable} from '@angular/core';
import {AeroComponent} from '../content/aero/aero.component';

@Injectable()
export class AeroCanDeactService implements CanDeactivate<AeroComponent>{

  constructor(private router: Router) {}

  canDeactivate(component: AeroComponent): boolean{
    if (component.aeroF.dirty) {
      return window.confirm('Are you sure you want to discard your changes?');
    }

    return true;
  }
}

