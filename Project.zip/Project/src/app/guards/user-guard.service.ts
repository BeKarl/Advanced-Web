import {ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot} from '@angular/router';
import {Injectable} from '@angular/core';
import {UserService} from '../service/user.service';

@Injectable()
export class UserGuardService implements CanActivate {

  constructor(private router: Router,
              // private userService: UserService
  ) {}

  canActivate(route: ActivatedRouteSnapshot,
              state: RouterStateSnapshot): boolean {

    console.log('we are in canActivate method!');

    // if (!this.userService.isLoggedIn()) {
    //   this.router.navigate(['login']);
    //   return false;
    // }

    return true;
  }
}
