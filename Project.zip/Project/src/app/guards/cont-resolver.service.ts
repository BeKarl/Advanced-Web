import {ActivatedRouteSnapshot, Resolve, RouterStateSnapshot} from '@angular/router';
import {Injectable} from '@angular/core';
import {User} from '../../user';
import {Observable} from 'rxjs';

@Injectable()
export class ContResolverService implements Resolve<User[]>{

  constructor() {}
  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<User[]> | Promise<User[]> | User[]{
    let user: User[] =[
      {
        id: 2,
        name: 'string',
        firstname: 'string',
        lastname: 'string',
        email: 'string',
        age: 12
      }
        ];
    return user;
  }
}

