import { TransforPipe } from './transfor.pipe';

describe('TransforPipe', () => {
  it('create an instance', () => {
    const pipe = new TransforPipe();
    expect(pipe).toBeTruthy();
  });
});
