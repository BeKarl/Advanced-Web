import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'transfor'
})
export class TransforPipe implements PipeTransform {

  transform(value: number, args?: any): string {

    return value.toString().replace('.', ',');
  }

}
