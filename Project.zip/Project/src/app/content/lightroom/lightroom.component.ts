import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lightroom',
  templateUrl: './lightroom.component.html',
  styleUrls: ['./lightroom.component.css']
})
export class LightroomComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
