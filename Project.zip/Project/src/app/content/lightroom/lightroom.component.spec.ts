import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LightroomComponent } from './lightroom.component';

describe('LightroomComponent', () => {
  let component: LightroomComponent;
  let fixture: ComponentFixture<LightroomComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LightroomComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LightroomComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
