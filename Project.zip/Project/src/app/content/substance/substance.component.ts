import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-substance',
  templateUrl: './substance.component.html',
  styleUrls: ['./substance.component.css']
})
export class SubstanceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
