import {Component, OnInit, ViewChild} from '@angular/core';
import {FormControl} from '@angular/forms';

@Component({
  selector: 'app-aero',
  templateUrl: './aero.component.html',
  styleUrls: ['./aero.component.css']
})
export class AeroComponent implements OnInit {
  aeroF: FormControl = new FormControl();
  num = 0;
  constructor() { }

  ngOnInit(): void {
  }

}
