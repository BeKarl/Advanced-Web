import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aftereffect',
  templateUrl: './aftereffect.component.html',
  styleUrls: ['./aftereffect.component.css']
})
export class AftereffectComponent implements OnInit {
  persentage: number = 0.14;
  constructor() { }

  ngOnInit(): void {
  }

}
