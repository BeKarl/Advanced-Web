import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AftereffectComponent } from './aftereffect.component';

describe('AftereffectComponent', () => {
  let component: AftereffectComponent;
  let fixture: ComponentFixture<AftereffectComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AftereffectComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AftereffectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
