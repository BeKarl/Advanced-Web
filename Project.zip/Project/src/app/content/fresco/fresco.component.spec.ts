import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FrescoComponent } from './fresco.component';

describe('FrescoComponent', () => {
  let component: FrescoComponent;
  let fixture: ComponentFixture<FrescoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FrescoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FrescoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
