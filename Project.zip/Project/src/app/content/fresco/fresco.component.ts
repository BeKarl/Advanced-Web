import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fresco',
  templateUrl: './fresco.component.html',
  styleUrls: ['./fresco.component.css']
})
export class FrescoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
