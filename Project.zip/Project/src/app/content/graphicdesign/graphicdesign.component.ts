import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-graphicdesign',
  templateUrl: './graphicdesign.component.html',
  styleUrls: ['./graphicdesign.component.css']
})
export class GraphicdesignComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
