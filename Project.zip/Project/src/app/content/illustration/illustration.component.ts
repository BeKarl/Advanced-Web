import {
  AfterContentChecked,
  AfterContentInit,
  AfterViewChecked,
  AfterViewInit,
  Component,
  DoCheck,
  Input,
  OnChanges,
  OnInit
} from '@angular/core';

@Component({
  selector: 'app-illustration',
  templateUrl: './illustration.component.html',
  styleUrls: ['./illustration.component.css']
})
export class IllustrationComponent implements  OnInit, DoCheck,
  AfterContentInit, AfterContentChecked, AfterViewInit, AfterViewChecked {
  @Input() message = 'qwe';
  constructor() {
    console.log('IllustrationComponent:Constructor');
  }
  ngOnInit(): void  { console.log('IllustrationComponent:OnInit', this.message); }
  ngDoCheck(): void  { console.log('IllustrationComponent:DoCheck', this.message); }
  ngAfterContentInit(): void  { console.log('IllustrationComponent:AfterContentInit', this.message); }
  ngAfterContentChecked(): void {console.log('IllustrationComponent:AfterContentChecked', this.message); }
  ngAfterViewInit(): void  { console.log('IllustrationComponent:AfterViewInit', this.message); }
  ngAfterViewChecked(): void  { console.log('IllustrationComponent:AfterViewChecked', this.message); }
}
