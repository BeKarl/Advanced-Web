import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PrimerproComponent } from './primerpro.component';

describe('PrimerproComponent', () => {
  let component: PrimerproComponent;
  let fixture: ComponentFixture<PrimerproComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PrimerproComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PrimerproComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
