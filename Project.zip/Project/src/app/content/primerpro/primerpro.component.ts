import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-primerpro',
  templateUrl: './primerpro.component.html',
  styleUrls: ['./primerpro.component.css']
})
export class PrimerproComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
