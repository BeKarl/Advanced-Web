import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-photoshop',
  templateUrl: './photoshop.component.html',
  styleUrls: ['./photoshop.component.css']
})
export class PhotoshopComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
