import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {BestComponent} from './best/best.component';
import {PhotoComponent} from './photo/photo.component';
import {IllustrationComponent} from './illustration/illustration.component';
import {ArchitectureComponent} from './architecture/architecture.component';
import {UserGuardService} from '../guards/user-guard.service';
import {MovementComponent} from './movement/movement.component';
import {ContResolverService} from '../guards/cont-resolver.service';
import {GamedesignComponent} from './gamedesign/gamedesign.component';
import {SoundComponent} from './sound/sound.component';
import {GraphicdesignComponent} from './graphicdesign/graphicdesign.component';
import {PhotoshopComponent} from './photoshop/photoshop.component';
import {IllustratorComponent} from './illustrator/illustrator.component';
import {AeroComponent} from './aero/aero.component';
import {AeroCanDeactService} from '../guards/aero-can-deact.service';
import {LightroomComponent} from './lightroom/lightroom.component';
import {InDesignComponent} from './in-design/in-design.component';
import {PrimerproComponent} from './primerpro/primerpro.component';
import {AftereffectComponent} from './aftereffect/aftereffect.component';
import {StockComponent} from './stock/stock.component';
import {DimensionComponent} from './dimension/dimension.component';
import {CaptureComponent} from './capture/capture.component';
import {FrescoComponent} from './fresco/fresco.component';
import {SubstanceComponent} from './substance/substance.component';
import {NouvelleetiqComponent} from './best/nouvelleetiq/nouvelleetiq.component';
import {NealgrundyComponent} from './best/nealgrundy/nealgrundy.component';
import {CathalduaneComponent} from './best/cathalduane/cathalduane.component';
import {TengyuComponent} from './best/tengyu/tengyu.component';
import {TeamxComponent} from './best/teamx/teamx.component';
import {NiceshitComponent} from './best/niceshit/niceshit.component';
import {AllanpetersComponent} from './best/allanpeters/allanpeters.component';
import {RobertpeekComponent} from './best/robertpeek/robertpeek.component';
import {SveinnspeightComponent} from './photo/sveinnspeight/sveinnspeight.component';
import {DarrenmartinComponent} from './photo/darrenmartin/darrenmartin.component';

const routes: Routes = [
  { path: '', component: BestComponent,  children:[
    {path:'Best/Nouvelleétiquette', component: NouvelleetiqComponent},
    {path:'Best/NealGrundy', component: NealgrundyComponent},
    {path:'Best/CathalDuane', component: CathalduaneComponent},
    {path:'Best/TengYu', component: TengyuComponent},
    {path:'Best/TeamX', component: TeamxComponent},
    {path:'Best/NiceshitStudio', component: NiceshitComponent},
    {path:'Best/Allanpeters', component: AllanpetersComponent},
    {path:'Best/Robertpeek', component: RobertpeekComponent}
  ]},
  { path: 'photo', component: PhotoComponent, children:[
      { path: 'Sveinnspeight', component: SveinnspeightComponent},
      { path: 'Darrenmartin', component: DarrenmartinComponent},
    ]},
  { path: 'illustrations', component: IllustrationComponent},
  { path: 'architecture', component: ArchitectureComponent, canActivate: [UserGuardService]},
  { path: 'movement', component: MovementComponent, resolve: {user: ContResolverService}},
  { path: 'gamedesign', component: GamedesignComponent},
  { path: 'sound', component: SoundComponent},
  { path: 'graphicdesign', component: GraphicdesignComponent},
  { path: 'photoshop', component: PhotoshopComponent},
  { path: 'illustrator', component: IllustratorComponent},
  { path: 'aero', component: AeroComponent, canDeactivate: [AeroCanDeactService]},
  { path: 'lightroom', component: LightroomComponent},
  { path: 'inDesign', component: InDesignComponent},
  { path: 'primerpro', component: PrimerproComponent},
  { path: 'aftereffect', component: AftereffectComponent},
  { path: 'stock', component: StockComponent},
  { path: 'dimension', component: DimensionComponent},
  { path: 'capture', component: CaptureComponent},
  { path: 'fresco', component: FrescoComponent},
  { path: 'substance', component: SubstanceComponent}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ContentRoutingModule { }
