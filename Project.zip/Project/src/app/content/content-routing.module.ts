import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {BestComponent} from './best/best.component';
import {PhotoComponent} from './photo/photo.component';
import {IllustrationComponent} from './illustration/illustration.component';
import {ArchitectureComponent} from './architecture/architecture.component';
import {UserGuardService} from '../guards/user-guard.service';
import {MovementComponent} from './movement/movement.component';
import {ContResolverService} from '../guards/cont-resolver.service';
import {GamedesignComponent} from './gamedesign/gamedesign.component';
import {SoundComponent} from './sound/sound.component';
import {GraphicdesignComponent} from './graphicdesign/graphicdesign.component';
import {PhotoshopComponent} from './photoshop/photoshop.component';
import {IllustratorComponent} from './illustrator/illustrator.component';
import {AeroComponent} from './aero/aero.component';
import {AeroCanDeactService} from '../guards/aero-can-deact.service';
import {LightroomComponent} from './lightroom/lightroom.component';
import {InDesignComponent} from './in-design/in-design.component';
import {PrimerproComponent} from './primerpro/primerpro.component';
import {AftereffectComponent} from './aftereffect/aftereffect.component';
import {StockComponent} from './stock/stock.component';
import {DimensionComponent} from './dimension/dimension.component';
import {CaptureComponent} from './capture/capture.component';
import {FrescoComponent} from './fresco/fresco.component';
import {SubstanceComponent} from './substance/substance.component';
import {NouvelleetiqComponent} from './best/nouvelleetiq/nouvelleetiq.component';
import {NealgrundyComponent} from './best/nealgrundy/nealgrundy.component';
import {CathalduaneComponent} from './best/cathalduane/cathalduane.component';
import {TengyuComponent} from './best/tengyu/tengyu.component';
import {TeamxComponent} from './best/teamx/teamx.component';
import {NiceshitComponent} from './best/niceshit/niceshit.component';
import {AllanpetersComponent} from './best/allanpeters/allanpeters.component';
import {RobertpeekComponent} from './best/robertpeek/robertpeek.component';
import {SveinnspeightComponent} from './photo/sveinnspeight/sveinnspeight.component';
import {DarrenmartinComponent} from './photo/darrenmartin/darrenmartin.component';
import {AngularFireAuthGuard, redirectUnauthorizedTo} from '@angular/fire/auth-guard';
import {LoginComponent} from '../auth/components/login/login.component';
const redirectUnauthorizedToLogin = () => redirectUnauthorizedTo(['login']);
const routes: Routes = [
  { path: '', component: BestComponent,  children:[
    {path:'Best/Nouvelleétiquette', component: NouvelleetiqComponent},
    {path:'Best/NealGrundy', component: NealgrundyComponent},
    {path:'Best/CathalDuane', component: CathalduaneComponent},
    {path:'Best/TengYu', component: TengyuComponent},
    {path:'Best/TeamX', component: TeamxComponent},
    {path:'Best/NiceshitStudio', component: NiceshitComponent},
    {path:'Best/Allanpeters', component: AllanpetersComponent},
    {path:'Best/Robertpeek', component: RobertpeekComponent}
  ]},
  { path: 'photo', component: PhotoComponent, children:[
      { path: 'Sveinnspeight', component: SveinnspeightComponent},
      { path: 'Darrenmartin', component: DarrenmartinComponent},
    ], canActivate: [AngularFireAuthGuard], data: { authGuardPipe: redirectUnauthorizedToLogin }},
  { path: 'illustrations', component: IllustrationComponent, canActivate: [AngularFireAuthGuard], data: { authGuardPipe: redirectUnauthorizedToLogin }},
  { path: 'architecture', component: ArchitectureComponent, canActivate: [AngularFireAuthGuard], data: { authGuardPipe: redirectUnauthorizedToLogin }},
  { path: 'movement', component: MovementComponent, resolve: {user: ContResolverService}, canActivate: [AngularFireAuthGuard], data: { authGuardPipe: redirectUnauthorizedToLogin }},
  { path: 'gamedesign', component: GamedesignComponent, canActivate: [AngularFireAuthGuard], data: { authGuardPipe: redirectUnauthorizedToLogin }},
  { path: 'sound', component: SoundComponent, canActivate: [AngularFireAuthGuard], data: { authGuardPipe: redirectUnauthorizedToLogin }},
  { path: 'graphicdesign', component: GraphicdesignComponent, canActivate: [AngularFireAuthGuard], data: { authGuardPipe: redirectUnauthorizedToLogin }},
  { path: 'photoshop', component: PhotoshopComponent, canActivate: [AngularFireAuthGuard], data: { authGuardPipe: redirectUnauthorizedToLogin }},
  { path: 'illustrator', component: IllustratorComponent, canActivate: [AngularFireAuthGuard], data: { authGuardPipe: redirectUnauthorizedToLogin }},
  { path: 'aero', component: AeroComponent, canDeactivate: [AeroCanDeactService], canActivate: [AngularFireAuthGuard], data: { authGuardPipe: redirectUnauthorizedToLogin }},
  { path: 'lightroom', component: LightroomComponent, canActivate: [AngularFireAuthGuard], data: { authGuardPipe: redirectUnauthorizedToLogin }},
  { path: 'inDesign', component: InDesignComponent, canActivate: [AngularFireAuthGuard], data: { authGuardPipe: redirectUnauthorizedToLogin }},
  { path: 'primerpro', component: PrimerproComponent, canActivate: [AngularFireAuthGuard], data: { authGuardPipe: redirectUnauthorizedToLogin }},
  { path: 'aftereffect', component: AftereffectComponent, canActivate: [AngularFireAuthGuard], data: { authGuardPipe: redirectUnauthorizedToLogin }},
  { path: 'stock', component: StockComponent, canActivate: [AngularFireAuthGuard], data: { authGuardPipe: redirectUnauthorizedToLogin }},
  { path: 'dimension', component: DimensionComponent, canActivate: [AngularFireAuthGuard], data: { authGuardPipe: redirectUnauthorizedToLogin }},
  { path: 'capture', component: CaptureComponent, canActivate: [AngularFireAuthGuard], data: { authGuardPipe: redirectUnauthorizedToLogin }},
  { path: 'fresco', component: FrescoComponent, canActivate: [AngularFireAuthGuard], data: { authGuardPipe: redirectUnauthorizedToLogin }},
  { path: 'substance', component: SubstanceComponent, canActivate: [AngularFireAuthGuard], data: { authGuardPipe: redirectUnauthorizedToLogin }}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ContentRoutingModule { }
