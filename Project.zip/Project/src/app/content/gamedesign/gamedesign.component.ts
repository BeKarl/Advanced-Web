import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gamedesign',
  templateUrl: './gamedesign.component.html',
  styleUrls: ['./gamedesign.component.css']
})
export class GamedesignComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
