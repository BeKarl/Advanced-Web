import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-illustrator',
  templateUrl: './illustrator.component.html',
  styleUrls: ['./illustrator.component.css']
})
export class IllustratorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
