import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TengyuComponent } from './tengyu.component';

describe('TengyuComponent', () => {
  let component: TengyuComponent;
  let fixture: ComponentFixture<TengyuComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TengyuComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TengyuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
