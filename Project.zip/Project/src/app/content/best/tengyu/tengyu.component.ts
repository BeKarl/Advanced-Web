import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tengyu',
  templateUrl: './tengyu.component.html',
  styleUrls: ['./tengyu.component.css']
})
export class TengyuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
