import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NiceshitComponent } from './niceshit.component';

describe('NiceshitComponent', () => {
  let component: NiceshitComponent;
  let fixture: ComponentFixture<NiceshitComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NiceshitComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NiceshitComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
