import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-niceshit',
  templateUrl: './niceshit.component.html',
  styleUrls: ['./niceshit.component.css']
})
export class NiceshitComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
