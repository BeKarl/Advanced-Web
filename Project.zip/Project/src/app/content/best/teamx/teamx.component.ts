import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-teamx',
  templateUrl: './teamx.component.html',
  styleUrls: ['./teamx.component.css']
})
export class TeamxComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
