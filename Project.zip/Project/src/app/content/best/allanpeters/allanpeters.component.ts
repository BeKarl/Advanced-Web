import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-allanpeters',
  templateUrl: './allanpeters.component.html',
  styleUrls: ['./allanpeters.component.css']
})
export class AllanpetersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
