import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AllanpetersComponent } from './allanpeters.component';

describe('AllanpetersComponent', () => {
  let component: AllanpetersComponent;
  let fixture: ComponentFixture<AllanpetersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AllanpetersComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AllanpetersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
