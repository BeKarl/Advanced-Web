import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NealgrundyComponent } from './nealgrundy.component';

describe('NealgrundyComponent', () => {
  let component: NealgrundyComponent;
  let fixture: ComponentFixture<NealgrundyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NealgrundyComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NealgrundyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
