import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nealgrundy',
  templateUrl: './nealgrundy.component.html',
  styleUrls: ['./nealgrundy.component.css']
})
export class NealgrundyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
