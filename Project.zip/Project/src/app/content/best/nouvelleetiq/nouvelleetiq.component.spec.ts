import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NouvelleetiqComponent } from './nouvelleetiq.component';

describe('NouvelleetiqComponent', () => {
  let component: NouvelleetiqComponent;
  let fixture: ComponentFixture<NouvelleetiqComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NouvelleetiqComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NouvelleetiqComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
