import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { GithubService } from '../../../service/github.service';

@Component({
  selector: 'app-nouvelleetiq',
  templateUrl: './nouvelleetiq.component.html',
  styleUrls: ['./nouvelleetiq.component.css']
})
export class NouvelleetiqComponent implements OnInit {
  // name: string = "";
  users:String[];
  response: any;
  constructor(private githubservice: GithubService) { }

  ngOnInit(): void {
  }
  getUsers(){
    this.githubservice.getData().subscribe((data)=>{
      console.log(data)
    })
  }
  // search(){
  //   this.http.get('https://gist.githubusercontent.com/BeKarl/d69044e26c9349cef930e3b6220137e3/raw/3d4ab8ea28c376e0a193c0b549888eac39ed291a/Content' + this.name)
  //     .subscribe((response)=>{
  //       this.response=response;
  //       console.log(this.response);
  //     })
  // }
}
