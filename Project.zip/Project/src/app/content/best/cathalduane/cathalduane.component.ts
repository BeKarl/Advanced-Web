import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cathalduane',
  templateUrl: './cathalduane.component.html',
  styleUrls: ['./cathalduane.component.css']
})
export class CathalduaneComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
