import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CathalduaneComponent } from './cathalduane.component';

describe('CathalduaneComponent', () => {
  let component: CathalduaneComponent;
  let fixture: ComponentFixture<CathalduaneComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CathalduaneComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CathalduaneComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
