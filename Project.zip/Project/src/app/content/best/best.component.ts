
import { Component, Input, OnChanges, OnInit } from '@angular/core';
import {HttpClient, HttpClientModule} from '@angular/common/http';

@Component({
  selector: 'app-best',
  templateUrl: './best.component.html',
  styleUrls: ['./best.component.css']
})
export class BestComponent implements   OnChanges, OnInit{
  show = false;
  UserName: string = "";
  response: any;

  @Input() value = 'Hello Beka';
  constructor(private http: HttpClient) {
    console.log('PhotoComponent:Constructor');
  }
  ngOnChanges(): void { console.log('PhotoComponent:OnChanges', this.value); }
  ngOnInit(): void  { console.log('PhotoComponent:OnInit', this.value); }



  }
