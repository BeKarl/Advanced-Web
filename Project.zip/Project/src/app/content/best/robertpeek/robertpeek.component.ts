import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-robertpeek',
  templateUrl: './robertpeek.component.html',
  styleUrls: ['./robertpeek.component.css']
})
export class RobertpeekComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
