import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RobertpeekComponent } from './robertpeek.component';

describe('RobertpeekComponent', () => {
  let component: RobertpeekComponent;
  let fixture: ComponentFixture<RobertpeekComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RobertpeekComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RobertpeekComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
