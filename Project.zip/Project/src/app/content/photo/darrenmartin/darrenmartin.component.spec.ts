import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DarrenmartinComponent } from './darrenmartin.component';

describe('DarrenmartinComponent', () => {
  let component: DarrenmartinComponent;
  let fixture: ComponentFixture<DarrenmartinComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DarrenmartinComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DarrenmartinComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
