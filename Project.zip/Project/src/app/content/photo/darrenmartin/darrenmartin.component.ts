import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-darrenmartin',
  templateUrl: './darrenmartin.component.html',
  styleUrls: ['./darrenmartin.component.css']
})
export class DarrenmartinComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
