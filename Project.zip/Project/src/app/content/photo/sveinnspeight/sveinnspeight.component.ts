import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sveinnspeight',
  templateUrl: './sveinnspeight.component.html',
  styleUrls: ['./sveinnspeight.component.css']
})
export class SveinnspeightComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
