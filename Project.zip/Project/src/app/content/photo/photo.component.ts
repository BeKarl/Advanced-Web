import {  Component,  OnInit,  OnDestroy,  Input} from '@angular/core';

@Component({
  selector: 'app-photo',
  templateUrl: './photo.component.html',
  styleUrls: ['./photo.component.css']
})
export class PhotoComponent implements  OnInit, OnDestroy {
  show = false;
  @Input() message = 'Hello Beka';
  constructor() {
    console.log('PhotoComponent:Constructor');
  }
  ngOnInit(): void  { console.log('PhotoComponent: OnInit', this.message); }
  ngOnDestroy(): void  { console.log('PhotoComponent: OnDestroy', this.message); }
}
