import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-in-design',
  templateUrl: './in-design.component.html',
  styleUrls: ['./in-design.component.css']
})
export class InDesignComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
