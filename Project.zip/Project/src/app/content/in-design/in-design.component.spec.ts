import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InDesignComponent } from './in-design.component';

describe('InDesignComponent', () => {
  let component: InDesignComponent;
  let fixture: ComponentFixture<InDesignComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InDesignComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InDesignComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
