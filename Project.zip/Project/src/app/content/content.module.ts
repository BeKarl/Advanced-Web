import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ContentRoutingModule } from './content-routing.module';
import {BestComponent} from './best/best.component';
import {PhotoComponent} from './photo/photo.component';
import {IllustrationComponent} from './illustration/illustration.component';
import {ArchitectureComponent} from './architecture/architecture.component';
import {MovementComponent} from './movement/movement.component';
import {GamedesignComponent} from './gamedesign/gamedesign.component';
import {SoundComponent} from './sound/sound.component';
import {GraphicdesignComponent} from './graphicdesign/graphicdesign.component';
import {PhotoshopComponent} from './photoshop/photoshop.component';
import {IllustratorComponent} from './illustrator/illustrator.component';
import {AeroComponent} from './aero/aero.component';
import {LightroomComponent} from './lightroom/lightroom.component';
import {InDesignComponent} from './in-design/in-design.component';
import {PrimerproComponent} from './primerpro/primerpro.component';
import {AftereffectComponent} from './aftereffect/aftereffect.component';
import {StockComponent} from './stock/stock.component';
import {DimensionComponent} from './dimension/dimension.component';
import {CaptureComponent} from './capture/capture.component';
import {FrescoComponent} from './fresco/fresco.component';
import {SubstanceComponent} from './substance/substance.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import { NouvelleetiqComponent } from './best/nouvelleetiq/nouvelleetiq.component';
import { NealgrundyComponent } from './best/nealgrundy/nealgrundy.component';
import { CathalduaneComponent } from './best/cathalduane/cathalduane.component';
import { TengyuComponent } from './best/tengyu/tengyu.component';
import { TeamxComponent } from './best/teamx/teamx.component';
import { NiceshitComponent } from './best/niceshit/niceshit.component';
import { AllanpetersComponent } from './best/allanpeters/allanpeters.component';
import { RobertpeekComponent } from './best/robertpeek/robertpeek.component';
import { SveinnspeightComponent } from './photo/sveinnspeight/sveinnspeight.component';
import { DarrenmartinComponent } from './photo/darrenmartin/darrenmartin.component';


@NgModule({
  declarations: [
    BestComponent,
    PhotoComponent,
    IllustrationComponent,
    ArchitectureComponent,
    MovementComponent,
    GamedesignComponent,
    SoundComponent,
    GraphicdesignComponent,
    PhotoshopComponent,
    IllustratorComponent,
    AeroComponent,
    LightroomComponent,
    InDesignComponent,
    PrimerproComponent,
    AftereffectComponent,
    StockComponent,
    DimensionComponent,
    CaptureComponent,
    FrescoComponent,
    SubstanceComponent,
    NouvelleetiqComponent,
    NealgrundyComponent,
    CathalduaneComponent,
    TengyuComponent,
    TeamxComponent,
    NiceshitComponent,
    AllanpetersComponent,
    RobertpeekComponent,
    SveinnspeightComponent,
    DarrenmartinComponent
  ],
  imports: [
    CommonModule,
    ContentRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    FormsModule
  ],
  exports: [
    BestComponent,
    PhotoComponent,
    IllustrationComponent,
    ArchitectureComponent,
    MovementComponent,
    GamedesignComponent,
    SoundComponent,
    GraphicdesignComponent,
    PhotoshopComponent,
    IllustratorComponent,
    AeroComponent,
    LightroomComponent,
    InDesignComponent,
    PrimerproComponent,
    AftereffectComponent,
    StockComponent,
    DimensionComponent,
    CaptureComponent,
    FrescoComponent,
    SubstanceComponent
  ]
})
export class ContentModule { }
