import { Component, OnInit } from '@angular/core';
import {Link} from './link';
import {LinkService} from '../../../../assigment6/src/app/link.service';
import {HttpClient} from '@angular/common/http';

@Component({
  selector: 'app-links',
  templateUrl: './links.component.html',
  styleUrls: ['./links.component.css']
})

export class LinksComponent implements OnInit {
  // linkListRow: Link[];
  // linkListRow1: Link[];
  // linkListRow2: Link[];
  // linkListRow3: Link[];
  // linkListRow4: Link[];
  constructor( private linkService: LinkService, private http: HttpClient) {
    // this.linkListRow = this.linkService.getLinksRow();
    // this.linkListRow1 = this.linkService.getLinksRow1();
    // this.linkListRow2 = this.linkService.getLinksRow2();
    // this.linkListRow3 = this.linkService.getLinksRow3();
    // this.linkListRow4 = this.linkService.getLinksRow4();
  }

  Row1: any;
  Row2: any;
  Row3: any;
  Row4: any;
  ngOnInit(): void {
    const response1 = this.http.get('https://raw.githubusercontent.com/BeKarl/Advanced-Web/master/Row1.json');
    response1.subscribe( (data: Object)=> this.Row1 = data );
    response1.subscribe( (data: Object ) => console.log(data));
    const response2 = this.http.get('https://raw.githubusercontent.com/BeKarl/Advanced-Web/master/Row2.json');
    response2.subscribe( (data: Object)=> this.Row2 = data );
    response2.subscribe( (data: Object ) => console.log(data));
    const response3 = this.http.get('https://raw.githubusercontent.com/BeKarl/Advanced-Web/master/Row3.json');
    response3.subscribe( (data: Object)=> this.Row3 = data );
    response3.subscribe( (data: Object ) => console.log(data));
    const response4 = this.http.get('https://raw.githubusercontent.com/BeKarl/Advanced-Web/master/Row4.json');
    response4.subscribe( (data: Object)=> this.Row4 = data );
    response4.subscribe( (data: Object ) => console.log(data));
  }

  imageObject: Array<object> = [{
    image: 'https://mir-s3-cdn-cf.behance.net/projects/404/41e610104110661.Y3JvcCwzODM1LDMwMDAsODUsMA.jpg',
    thumbImage: 'https://mir-s3-cdn-cf.behance.net/projects/404/41e610104110661.Y3JvcCwzODM1LDMwMDAsODUsMA.jpg',
    alt: 'Лучшее из Behance',
    title: 'Лучшее из Behance'
  },{image: 'https://mir-s3-cdn-cf.behance.net/projects/404/68c813104058463.Y3JvcCwxNjg3LDEzMjAsMTU0LDA.jpg',
    thumbImage: 'https://mir-s3-cdn-cf.behance.net/projects/404/68c813104058463.Y3JvcCwxNjg3LDEzMjAsMTU0LDA.jpg',
    alt: 'Фотография',
    title: 'Фотография'
  },{image: 'https://mir-s3-cdn-cf.behance.net/projects/404/d46e8e64498789.Y3JvcCwyNjQ3LDIwNzIsNzUxLDQ1MQ.jpg',
    thumbImage: 'https://mir-s3-cdn-cf.behance.net/projects/404/d46e8e64498789.Y3JvcCwyNjQ3LDIwNzIsNzUxLDQ1MQ.jpg',
    alt: 'Иллюстрация',
    title: 'Иллюстрация'
  },{image: 'https://mir-s3-cdn-cf.behance.net/projects/404/5562b9104384657.Y3JvcCw2NTcsNTE0LDI0MCww.jpg',
    thumbImage: 'https://mir-s3-cdn-cf.behance.net/projects/404/5562b9104384657.Y3JvcCw2NTcsNTE0LDI0MCww.jpg',
    alt: 'Архитектура',
    title: 'Архитектура'
  },
    {image: 'https://mir-s3-cdn-cf.behance.net/projects/404/ebda7f104529121.Y3JvcCwxMTY4LDkxNCwyMzEsMA.png',
    thumbImage: 'https://mir-s3-cdn-cf.behance.net/projects/404/ebda7f104529121.Y3JvcCwxMTY4LDkxNCwyMzEsMA.png',
    alt: 'Движение',
    title: 'Движение'
   },{image: 'https://mir-s3-cdn-cf.behance.net/projects/404/5c9f5a49359655.Y3JvcCw5NzUsNzYzLDIxMiw3OQ.png',
    thumbImage: 'https://mir-s3-cdn-cf.behance.net/projects/404/5c9f5a49359655.Y3JvcCw5NzUsNzYzLDIxMiw3OQ.png',
    alt: 'Игровой дизайн',
    title: 'Игровой дизайн'
  },{image: 'https://mir-s3-cdn-cf.behance.net/projects/404/25034672207663.Y3JvcCwxODQxLDE0NDAsMzE4LDA.png',
    thumbImage: 'https://mir-s3-cdn-cf.behance.net/projects/404/25034672207663.Y3JvcCwxODQxLDE0NDAsMzE4LDA.png',
    alt: 'Звук',
    title: 'Звук'
  },{image: 'https://mir-s3-cdn-cf.behance.net/projects/404/e4e9a571509297.Y3JvcCwxMDA3LDc4OCwxOTcsMA.jpg',
    thumbImage: 'https://mir-s3-cdn-cf.behance.net/projects/404/e4e9a571509297.Y3JvcCwxMDA3LDc4OCwxOTcsMA.jpg',
    alt: 'Графический дизайн',
    title: 'Графический дизайн'
  },{image: 'https://mir-s3-cdn-cf.behance.net/projects/404/7fc86581387861.Y3JvcCwxNDAwLDEwOTUsMCwxNTI.jpg',
    thumbImage: 'https://mir-s3-cdn-cf.behance.net/projects/404/7fc86581387861.Y3JvcCwxNDAwLDEwOTUsMCwxNTI.jpg',
    alt: 'Photoshop',
    title: 'Photoshop'
  },{image: 'https://mir-s3-cdn-cf.behance.net/projects/404/0a556486658937.Y3JvcCw0MDQsMzE2LDAsMA.jpg',
    thumbImage: 'https://mir-s3-cdn-cf.behance.net/projects/404/0a556486658937.Y3JvcCw0MDQsMzE2LDAsMA.jpg',
    alt: 'Illustrator',
    title: 'Illustrator'
  },{image: 'https://mir-s3-cdn-cf.behance.net/projects/404/78d7eb87663977.Y3JvcCw0MDQsMzE2LDAsMA.jpg',
    thumbImage: 'https://mir-s3-cdn-cf.behance.net/projects/404/78d7eb87663977.Y3JvcCw0MDQsMzE2LDAsMA.jpg',
    alt: 'Aero',
    title: 'Aero'
  },{image: 'https://mir-s3-cdn-cf.behance.net/projects/404/711363104631209.Y3JvcCwxOTE3LDE1MDAsMTY2LDA.jpg',
    thumbImage: 'https://mir-s3-cdn-cf.behance.net/projects/404/711363104631209.Y3JvcCwxOTE3LDE1MDAsMTY2LDA.jpg',
    alt: 'Lightroom',
    title: 'Lightroom'
  },{image: 'https://mir-s3-cdn-cf.behance.net/projects/404/68257294421605.Y3JvcCwxMzgzLDEwODIsNiww.jpg',
    thumbImage: 'https://mir-s3-cdn-cf.behance.net/projects/404/68257294421605.Y3JvcCwxMzgzLDEwODIsNiww.jpg',
    alt: 'InDesign',
    title: 'InDesign'
  },{image: 'https://mir-s3-cdn-cf.behance.net/projects/404/795ef099224603.Y3JvcCw4OTcsNzAyLDE5MSw4.jpg',
    thumbImage: 'https://mir-s3-cdn-cf.behance.net/projects/404/795ef099224603.Y3JvcCw4OTcsNzAyLDE5MSw4.jpg',
    alt: 'Premiere Pro',
    title: 'Premiere Pro'
  },{image: 'https://mir-s3-cdn-cf.behance.net/projects/404/9c26a7103041379.Y3JvcCwxMDEzLDc5MiwxMTE0LDU2NA.jpg',
    thumbImage: 'https://mir-s3-cdn-cf.behance.net/projects/404/9c26a7103041379.Y3JvcCwxMDEzLDc5MiwxMTE0LDU2NA.jpg',
    alt: 'After Effects',
    title: 'After Effects'
  },{image: 'https://mir-s3-cdn-cf.behance.net/projects/404/ce703d100411637.Y3JvcCw4MDgsNjMyLDAsMA.png',
    thumbImage: 'https://mir-s3-cdn-cf.behance.net/projects/404/ce703d100411637.Y3JvcCw4MDgsNjMyLDAsMA.png',
    alt: 'Stock',
    title: 'Stock'
  },{image: 'https://mir-s3-cdn-cf.behance.net/projects/404/51362c104606645.Y3JvcCwxMDA3LDc4OCwxOTcsMA.jpg',
    thumbImage: 'https://mir-s3-cdn-cf.behance.net/projects/404/51362c104606645.Y3JvcCwxMDA3LDc4OCwxOTcsMA.jpg',
    alt: 'Dimension',
    title: 'Dimension'
  },{image: 'https://mir-s3-cdn-cf.behance.net/projects/404/3e721893828747.Y3JvcCw5MjQsNzIyLDYxNSwxNzY.jpg',
    thumbImage: 'https://mir-s3-cdn-cf.behance.net/projects/404/3e721893828747.Y3JvcCw5MjQsNzIyLDYxNSwxNzY.jpg',
    alt: 'Capture',
    title: 'Capture'
  },{image: 'https://mir-s3-cdn-cf.behance.net/projects/404/c9b7ec104923895.5f6d79c5c3b42.jpg',
    thumbImage: 'https://mir-s3-cdn-cf.behance.net/projects/404/c9b7ec104923895.5f6d79c5c3b42.jpg',
    alt: 'Fresco',
    title: 'Fresco'
  },{image: 'https://mir-s3-cdn-cf.behance.net/projects/404/57953e102201811.Y3JvcCwyODYzLDIyNDAsNTY3LDA.jpg',
    thumbImage: 'https://mir-s3-cdn-cf.behance.net/projects/404/57953e102201811.Y3JvcCwyODYzLDIyNDAsNTY3LDA.jpg',
    alt: 'Substance Alchemist',
    title: 'Substance Alchemist'
  }
  ];
}
