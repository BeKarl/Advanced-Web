import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormControl, FormGroup, NgForm, Validators} from '@angular/forms';
import {AngularFireAction} from '@angular/fire/database';
import {AngularFireAuth} from '@angular/fire/auth';
import {Router} from '@angular/router';
// import {AuthService} from '../../../shared/services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  constructor(private fb: FormBuilder, private auth: AngularFireAuth, private router: Router) {
  }
  // constructor(private authService: AuthService) {
  // }

  ngOnInit(): void {
    this.loginForm = this.fb.group({
      email: new FormControl('', Validators.required),
      password: new FormControl('', Validators.required),
    })
  }

  onSubmit(f: NgForm) {
    // this.authService.login(f.value);
    // const loginObserver = {
    //   next: x => console.log('User logged in'),
    //   error: err => console.log(err)
    // };
    // this.authService.login(f.value).subscribe(loginObserver);
  }
  onLogin(){
    const{email, password} = this.loginForm.value;
    this.auth.signInWithEmailAndPassword(email, password).then(()=>this.router.navigate(['']))

}
}
