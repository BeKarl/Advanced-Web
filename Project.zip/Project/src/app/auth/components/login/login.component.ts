import { Component, OnInit } from '@angular/core';
import {NgForm} from '@angular/forms';
// import {AuthService} from '../../../shared/services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  constructor() {
  }
  // constructor(private authService: AuthService) {
  // }

  ngOnInit(): void {
  }

  onSubmit(f: NgForm) {
    // this.authService.login(f.value);
    // const loginObserver = {
    //   next: x => console.log('User logged in'),
    //   error: err => console.log(err)
    // };
    // this.authService.login(f.value).subscribe(loginObserver);
  }

}
