import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormControl, FormGroup, NgForm, Validators} from '@angular/forms';
import { AngularFireAuth } from '@angular/fire/auth';
import firebase from 'firebase/app';
import {Router} from '@angular/router';
// import { AuthService } from 'src/app/shared/services/auth.service';
// import { ProgressBarService } from 'src/app/shared/services/progress-bar.service';
// import { AlertService } from 'ngx-alerts';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {
  registerForm: FormGroup;
  // constructor(private authService: AuthService, public progressBar: ProgressBarService,
  //             private alertService: AlertService) { }
  constructor(private fb: FormBuilder, private auth: AngularFireAuth, private router: Router) {
  }
  ngOnInit() :void{
    this.registerForm = this.fb.group({
      email: new FormControl('', Validators.required),
      password: new FormControl('', [Validators.required, Validators.minLength(6)])
    })
  }
  createUser(){
    const{email, password} = this.registerForm.value;
    this.auth.createUserWithEmailAndPassword(email, password).then((user)=>{
      console.log('RegisterComponent -> createUser -> user', user);
      this.router.navigate(['']);
    })
  }
  onSubmit(f: NgForm) {
    // this.alertService.info('Working on creating new account');
    // this.progressBar.startLoading();
    // const registerObserver = {
    //   next: x => {
    //     this.progressBar.setSuccess();
    //     console.log('User created');
    //     this.alertService.success('Account Created');
    //     this.progressBar.completeLoading();
    //   },
    //   error: err => {
    //     this.progressBar.setError();
    //     console.log(err);
    //     this.alertService.danger(err.error.errors[0].description);
    //     this.progressBar.completeLoading();
    //   }
    // };
    // this.authService.register(f.value).subscribe(registerObserver);
  }
}
