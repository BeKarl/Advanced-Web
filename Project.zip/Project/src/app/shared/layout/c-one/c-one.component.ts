import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-c-one',
  templateUrl: './c-one.component.html',
  styleUrls: ['./c-one.component.css']
})
export class COneComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
