import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { COneComponent } from './layout/c-one/c-one.component';
import { HeaderComponent } from './components/header/header.component';
import {RouterModule} from '@angular/router';



@NgModule({
  declarations: [COneComponent, HeaderComponent],
  imports: [
    CommonModule,
    RouterModule
  ],
  exports: [
    COneComponent
  ]
})
export class SharedModule { }
