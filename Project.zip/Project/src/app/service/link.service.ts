import { Injectable } from '@angular/core';
import {Link} from '../links/link';

@Injectable({
  providedIn: 'root'
})
export class LinkService {

  constructor() { }
  getLinksRow1() {let linkListRow1: Link[];
                  linkListRow1 = [
      new Link('', 'Лучшее'),
      new Link('photo', 'Фотография'),
      new Link('illustrations', 'Иллюстрация'),
      new Link('architecture', 'Архетиктура'),
      new Link('movement', 'Движение')
    ];
                  return linkListRow1;
  }
  getLinksRow2() {let linkListRow2: Link[];
                  linkListRow2 = [
      new Link('gamedesign', 'Игровой дизайн'),
      new Link('sound', 'Звук'),
      new Link('graphicdesign', 'Графический дизайн'),
      new Link('photoshop', 'Photoshop'),
      new Link('illustrator', 'Illustrator')
    ];
                  return linkListRow2;
  }
  getLinksRow3() {
    let linkListRow3: Link[];
    linkListRow3 = [
      new Link('aero', 'Aero'),
      new Link('lightroom', 'Lightroom'),
      new Link('inDesign', 'InDesign'),
      new Link('primerpro', 'Primer Pro'),
      new Link('aftereffect', 'After Effect')
    ];
    return linkListRow3;

  }
  getLinksRow4() {
    let linkListRow4: Link[];
    linkListRow4 = [
      new Link('stock', 'Stock'),
      new Link('dimension', 'Dimension'),
      new Link('capture', 'Capture'),
      new Link('fresco', 'Fresco'),
      new Link('substance', 'Substance')
    ];
    return linkListRow4;

  }
}
